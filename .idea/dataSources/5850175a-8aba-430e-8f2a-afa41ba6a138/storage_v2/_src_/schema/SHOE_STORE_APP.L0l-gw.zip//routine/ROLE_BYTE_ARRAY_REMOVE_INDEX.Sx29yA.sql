create function role_byte_array_remove_index(arr in role_byte_array, idx in number) return role_byte_array deterministic is res role_byte_array:=role_byte_array(); begin if arr is null or idx is null then return arr; end if; for i in 1 .. arr.count loop if i<>idx then res.extend; res(res.last) := arr(i); end if; end loop; return res; end;
/

