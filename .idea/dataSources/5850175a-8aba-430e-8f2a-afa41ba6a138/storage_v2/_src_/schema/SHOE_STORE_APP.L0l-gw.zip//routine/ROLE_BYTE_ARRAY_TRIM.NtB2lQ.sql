create function role_byte_array_trim(arr in role_byte_array, elems number) return role_byte_array deterministic is res role_byte_array:=role_byte_array(); begin if arr is null or elems is null then return null; end if; if arr.count < elems then raise_application_error (-20000, 'number of elements to trim must be between 0 and '||arr.count); end if;for i in 1 .. arr.count-elems loop res.extend; res(i) := arr(i); end loop; return res; end;
/

