create function role_byte_array_reverse(arr in role_byte_array) return role_byte_array deterministic is res role_byte_array:=role_byte_array(); begin if arr is null then return null; end if; for i in reverse 1 .. arr.count loop res.extend; res(res.count) := arr(i); end loop; return res; end;
/

