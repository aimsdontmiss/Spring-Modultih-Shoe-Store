create function role_byte_array_replace(arr in role_byte_array, old in number, elem in number) return role_byte_array deterministic is res role_byte_array:=role_byte_array(); begin if arr is null then return null; end if; if old is null then for i in 1 .. arr.count loop res.extend; res(res.last) := coalesce(arr(i),elem); end loop; else for i in 1 .. arr.count loop res.extend; if arr(i) = old then res(res.last) := elem; else res(res.last) := arr(i); end if; end loop; end if; return res; end;
/

