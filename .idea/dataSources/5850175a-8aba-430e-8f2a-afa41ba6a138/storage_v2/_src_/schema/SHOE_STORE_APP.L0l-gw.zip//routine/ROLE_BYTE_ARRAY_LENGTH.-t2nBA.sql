create function role_byte_array_length(arr in role_byte_array) return number deterministic is begin if arr is null then return null; end if; return arr.count; end;
/

