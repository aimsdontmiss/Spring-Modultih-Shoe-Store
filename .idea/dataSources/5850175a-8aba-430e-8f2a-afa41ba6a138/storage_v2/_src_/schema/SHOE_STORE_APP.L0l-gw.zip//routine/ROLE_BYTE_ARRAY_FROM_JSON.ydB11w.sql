create function role_byte_array_from_json(arr in json) return role_byte_array deterministic is res role_byte_array:=role_byte_array(); begin if arr is null then return null; end if; select t.value bulk collect into res from json_table(arr,'$[*]' columns (value number(3,0) path '$')) t; return res; end;
/

