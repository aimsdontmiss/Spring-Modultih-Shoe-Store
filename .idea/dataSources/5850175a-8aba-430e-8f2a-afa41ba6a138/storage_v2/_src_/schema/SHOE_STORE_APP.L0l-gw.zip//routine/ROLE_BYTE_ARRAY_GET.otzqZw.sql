create function role_byte_array_get(arr in role_byte_array, idx in number) return number deterministic is begin if arr is null or idx is null or arr.count < idx then return null; end if; return arr(idx); end;
/

