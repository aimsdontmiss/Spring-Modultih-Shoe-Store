create function role_byte_array_set(arr in role_byte_array, idx in number, elem in number) return role_byte_array deterministic is res role_byte_array:=role_byte_array(); begin if arr is not null then for i in 1 .. arr.count loop res.extend; res(i) := arr(i); end loop; for i in arr.count+1 .. idx loop res.extend; end loop; else for i in 1 .. idx loop res.extend; end loop; end if; res(idx) := elem; return res; end;
/

