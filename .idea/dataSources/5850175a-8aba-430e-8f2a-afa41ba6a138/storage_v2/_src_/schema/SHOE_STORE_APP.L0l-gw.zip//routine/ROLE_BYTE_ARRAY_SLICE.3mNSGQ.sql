create function role_byte_array_slice(arr in role_byte_array, startIdx in number, endIdx in number) return role_byte_array deterministic is res role_byte_array:=role_byte_array(); begin if arr is null or startIdx is null or endIdx is null then return null; end if; for i in startIdx .. least(arr.count,endIdx) loop res.extend; res(res.last) := arr(i); end loop; return res; end;
/

